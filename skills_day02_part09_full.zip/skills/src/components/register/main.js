import React, { Component } from "react"
//
class Main extends Component {  
  // eslint-disable-next-line no-useless-constructor
  constructor(props) {
    super(props);
    this.state = {
      username:"",
      password:""
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleFieldChange = this.handleFieldChange.bind(this);
  }
//
  handleSubmit(event) {
    event.preventDefault();
    fetch(
      'http://localhost:3030/customers',
      {
        method: 'POST',
        headers: { 
          'Accept': 'application/json',
          'Content-Type': 'application/json'  
        },
        body: JSON.stringify({
          username: this.state.username,
          password:this.state.password
        })
      }
    ).then(response => console.log("Post successful " + response))
    .catch(err => console.log("Error occured " + err.message));

  }
//
  handleFieldChange(event) {
    this.setState({
      [event.target.name]:event.target.value
    })
  }
//
  render(){
    return (
      <main>
        <h2>Register to participate</h2>
        <form onSubmit={this.handleSubmit}>
          <div>
            <label>
              Name:
                <input type="text" name="username" onChange={this.handleFieldChange} />
            </label>
          </div>
          <div>
            <label>
              Password:
                <input type="text" name="password" onChange={this.handleFieldChange} />
            </label>
          </div>
          <div>
            <input type="submit" value="Submit" onChange={this.handleFieldChange} />
          </div>
        </form>
      </main>
    )
  }
}
//
export default Main
