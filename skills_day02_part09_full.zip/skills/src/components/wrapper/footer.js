import React from "react";
//
function Footer(){
  return (
    <footer>
      <hr />
      Copyright &copy; 2021. All rights reserved
    </footer>
  )
}
//
export default Footer
