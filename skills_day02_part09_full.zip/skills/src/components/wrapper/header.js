import React, {Component} from "react";
import { Link, withRouter } from 'react-router-dom';
import logo from './../../chart.gif';
//

//
class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {validUser: localStorage.getItem('validuser')};
    this.logOut = this.logOut.bind(this);
  }
  //
  logOut(){   
    localStorage.removeItem('validuser');
    this.setState((state) => ({validUser:null}));
    this.props.history.push('/home');    
  }
//
  render(){
    return (
      <header>
        <img src={logo} id="logo" alt="logo" />
        <h1><a href="index.html">Skillsoft Weight Tracker</a></h1>
        <nav>
          <ul>
            <li><Link to="/home">home</Link></li>
            <li><Link to="/register">register</Link></li>
            <li><Link to="/customers">customers</Link></li>
            { !this.state.validUser 
                ? <li className="moveRight"><Link to="/login">login</Link></li>
                : <li className="moveRight" onClick={this.logOut}><Link to="/logout">logout {this.state.validUser} </Link></li>
            } 
          </ul>
        </nav>
      </header>
    )
  }
}
//
export default withRouter(Header)
